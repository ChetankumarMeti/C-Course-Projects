#include <stdio.h>

int main(int argc, char **argv) {
	char str1[] = "Hello"; // str1 is an array of string 
	char *str2 = "Goodbye"; // str2 is pointer variable of type char store the address value of string
	// str2 = &str1;
	// str2 = str1;
	printf("%d %d %s\n", &str1, str1, str1);
	printf("%d %d %s\n", &str2, str2, str2);
	int var;
	scanf_s("%d", &var);
	return 0;
}
