#include <stdio.h>

int main(int argc, char **argv) {
	ptr_fun();
	int num;
	int *numPtr; // pointer variable of type int
	int num2;
	num = 100;
	numPtr = &num; // pointer points to address of variable num
	num2 = *numPtr; // derference or indirection
	printf("num=%d, numPtr=%d, address of num=%d, num2=%d\n", num, numPtr, &num, num2);
	printf("%p - %p ; %d - %d\n", numPtr, numPtr+5, numPtr, numPtr + 5);
	return 0;
}
