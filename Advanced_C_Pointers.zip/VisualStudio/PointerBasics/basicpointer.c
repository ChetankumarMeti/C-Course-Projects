void ptr_fun() {

	printf("Working on pointers basics");
}